from transformers import T5Tokenizer
import pickle
import torch

# Load the trained model
with open(r'algorithm\Text_Summarization_Model.pkl', 'rb') as f:
#with open(r'algorithm\text_summarization_model.pkl', 'rb') as f:
    model = pickle.load(f)

tokenizer = T5Tokenizer.from_pretrained("t5-base")
#headline_model = T5ForConditionalGeneration.from_pretrained("t5-base")


# Function of Document Summarization
def hugging_face_transformer(output_string):

    def encode_text(text):
        # Encode the text using the tokenizer
        encoding = tokenizer.encode_plus(
            text,
            max_length=512,
            padding="max_length",
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )
        return encoding["input_ids"], encoding["attention_mask"]

    def generate_summary(input_ids, attention_mask):
        # Generate a summary using the best model
        generated_ids = model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_length=150,
            num_beams=2,
            repetition_penalty=2.5,
            length_penalty=1.0,
            early_stopping=True
        )
        return generated_ids

    def decode_summary(generated_ids):
        # Decode the generated summary
        summary = [tokenizer.decode(gen_id, skip_special_tokens=True, clean_up_tokenization_spaces=True)
                   for gen_id in generated_ids]
        return "".join(summary)

    input_ids, attention_mask = encode_text(output_string)
    generated_ids = generate_summary(input_ids, attention_mask)
    summary = decode_summary(generated_ids)
    return summary



# Function for Plain Text Summarization
def custom_trained_model(text_content):
    def encode_text(text):
        # Encode the text using the tokenizer
        encoding = tokenizer.encode_plus(
            text,
            max_length=512,
            padding="max_length",
            truncation=True,
            return_attention_mask=True,
            return_tensors='pt'
        )
        return encoding["input_ids"], encoding["attention_mask"]

    def generate_summary(input_ids, attention_mask):
        # Generate a summary using the best model
        generated_ids = model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_length=150,
            num_beams=2,
            repetition_penalty=2.5,
            length_penalty=1.0,
            early_stopping=True
        )
        return generated_ids

    def decode_summary(generated_ids):
        # Decode the generated summary
        summary = [tokenizer.decode(gen_id, skip_special_tokens=True, clean_up_tokenization_spaces=True)
                   for gen_id in generated_ids]
        return "".join(summary)

    input_ids, attention_mask = encode_text(text_content)
    generated_ids = generate_summary(input_ids, attention_mask)
    summary = decode_summary(generated_ids)
    return summary
