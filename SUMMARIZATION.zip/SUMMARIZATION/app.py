from flask import Flask, render_template, request
from algorithm import allAlgorithms
import os

app = Flask(__name__,
            static_url_path='/assets',
            static_folder='./templates/assets',
            )



@app.route('/')
def index():
    return render_template('index.html')



@app.route('/home')
def home():
    # return render_template('index.html')
    return render_template('home.html')



@app.route('/transformer',methods=["POST"])
def transformer():

    folder = os.getcwd()+"\\"+"assignments"
    perc = request.form['transformer']

    print(perc)

    files = [folder+"\\"+doc for doc in os.listdir(folder) if doc.endswith('.txt')]

    all_files_data = []
    for File in files:
        all_files_data.append(open(File).read())

    summarized_data = []  
    for data in all_files_data:
        summarized_data.append(str(allAlgorithms.hugging_face_transformer(data)).replace("</s> %",''))
    
    for i in range(len(all_files_data)):
        print('\n\n\nActual\n',all_files_data[i],'\n\nSummarized\n',summarized_data[i])
    
    result = []
    for i in range(len(files)):
        result.append([files[i], all_files_data[i],summarized_data[i]])

    #return render_template('result.html',result=result,algorithm = 'Transformer Hugging Face Algorithm')
    return render_template('result.html',result=result)



@app.route('/index')
def ai_engine_page():
    return render_template('home.html')


    
@app.route('/singleSum')
def singleSum():
    return render_template('singleSum.html')



@app.route('/output',methods=['POST'])
def output():
    if request.method == 'POST':
        textvalue = request.form.get("textarea", None)
        return render_template('output.html', res=allAlgorithms.custom_trained_model(textvalue))



if __name__ == '__main__':
    app.run(debug=False)